<?php include'header.php'; ?>

<main class="glavno">
	<img src="slike/untitled.png" width="800px">
</main>

<?php include'footer.php'; ?>