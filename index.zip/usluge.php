<?php include'header.php'; ?>
<p><font color="#f4fc19"><strong>Clean MAx je firma koja se bavi čistoćom u svakom njenom obliku. Bavimo se čišćenjem svega od podova do posuđa. pored sredstava za čišćenje kod nas možete dobiti i uslugu čišćenja svega što poželite. </strong></font></p>
<main class="glavno">
	<img src="slike/slika3clean.jpg" width="800px">
</main>

<?php include'footer.php'; ?>