<?php include'header.php'; ?>

<p><font color="#f4fc19"><strong>"CLEANmax" stavlja kraj na dosadne kućanske poslove! Bez obzira na usisavanje, čišćenje prozora ili brisanje - s "CLEANmax" sve postaje divno jednostavno! Od modernih ciklona usisavače za kat skrb o kompaktnom bežični usisivač za čišćenje između do parni čistač za temeljitu čistoću sve je spremno, bez kemikalija.</strong></font></p>
<main class="glavno">
	<img src="slike/slike4clean.jpg" width="800px">
</main>
<p><font color="#f4fc19"><strong>Saznajte sve o Clean Max, našem brendu i našim proizvodima. Od sastojaka deterdženta za pranje rublja do savjeta o sigurnosti kod kuće i kako spasiti vodu u praonici, Clean Max je ovdje da vam pomogne da dobijete najbolje od pranja, bez obzira na to je li pomoć kod sigurnosti djece kod kuće, održivost ili jednostavno uklanjanje tih mrlja.</strong></font></p>

<?php include'footer.php'; ?>