<footer class="zaglavlje">
	<font color="#f4fc19"><p><strong>Adresa: Bolnička 32,Centar, Sarajevo,<br> 71000 Bosna i Hercegovina <br> Telefon : 00387 61 915 519</strong></p></font>

	
</footer>
</body>
</html>