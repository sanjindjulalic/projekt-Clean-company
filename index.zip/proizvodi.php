<?php include'header.php'; ?>

<p><font color="#f4fc19"><strong>U našim prodavnicama naćete širok asortiman sredstava za ćišćenje. Veliki broj detrđenata za suđe, podove , drvenariju, staklene površine itd..Pored toga naći ćete i veliki broj detrđenta za rublje. Garantujemo veliki izbor i opreme za čišćenje kao što su usisivači , metle , zogeri itd...</strong></font></p>
<main class="glavno">
	<img src="slike/slikaclean6.gif" width="800px">
</main>

<?php include'footer.php'; ?>