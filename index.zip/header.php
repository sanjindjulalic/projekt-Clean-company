<!DOCTYPE html>
<html>
<head>
	<title>CLEANMAX</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<header class ="logo">
		<img src="slike/cleanmax.png" width="800px" >
		<hr>
		
</header>
<table class="navigacija">
	<tr>
		<td><a href="index.html">Pocetna</a>
        <td><a href="proizvodi.html">Proizvodi</a>
        <td><a href="usluge.html">Usluge</a>
        <td><a href="onama.html">O nama</a>
	    <td><a href="kontakt.html">Kontakt</a>
		
	</tr>
</table>